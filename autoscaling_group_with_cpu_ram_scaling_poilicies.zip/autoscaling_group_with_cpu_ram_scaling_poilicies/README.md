# Autoscaling as per increase in RAM usage and CPU usage

## python script using aws boto3 and AWS autoscaling service.

This python script is used for creating launch configuration which will scale up and down as per RAM and CPU usage.
